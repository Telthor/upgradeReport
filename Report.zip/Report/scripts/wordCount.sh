#!/bin/bash
cd ..
TEXFILE='upgradeReport.tex'
texcount -inc $TEXFILE
